# -*- coding: utf-8 -*-
"""
Created on Sun Aug 27 13:25:48 2023

@author: Heng2020
"""
# pip install pgsrip
# choco install mkvtoolnix => 
############################### Still Not work ###########
from ungroupped02 import *
from pgsrip import pgsrip, Mkv, Options
from babelfish import Language

# Path to the input .mkv file
 # Update this with the correct path
input_mkv_file = r"C:/Users/Heng2020/OneDrive/Python MyLib/BigBang EN S06E03.mkv"
lang = Language('eng')
# obj_function(lang)
# obj_property(lang)
# media = Mkv(input_mkv_file)

# options = Options(languages={Language('eng')}, overwrite=True, one_per_lang=False)
# temp01 = media.get_pgs_medias(options)
# temp02 = [x for x in temp01 ]
# temp = pgsrip.rip(media,options)
